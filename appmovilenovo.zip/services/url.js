{/* COLOQUE AQUI SEU ENDEREÇO IP */}
const url =  'http://10.68.36.111/';
export default url;